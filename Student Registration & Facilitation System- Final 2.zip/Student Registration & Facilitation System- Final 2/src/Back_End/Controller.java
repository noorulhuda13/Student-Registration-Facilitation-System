package Back_End;

import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class Controller {

    @FXML
    private TextField nameText;

    @FXML
    private TextField lastnameText;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ChoiceBox<String> courseChoice1;

    @FXML
    private ChoiceBox<String> courseChoice2;

    @FXML
    private ChoiceBox<String> courseChoice3;

    @FXML
    private Button registerButton;

    @FXML
    private Label nameLabel;

    @FXML
    private Label idLabel;

    @FXML
    private Label course1;

    @FXML
    private Label course2;

    @FXML
    private Label course3;

    @FXML
    private Label ch1;

    @FXML
    private ImageView backreg;

    @FXML
    private Label ch2;

    @FXML
    private Label ch3;

    private List<Student> studentList = new ArrayList<>();

    @FXML
    public void initialize() {
        courseChoice1.getItems().addAll("PF", "Circuit Analysis", "OOP", "Discrete Structures");
        courseChoice2.getItems().addAll("Applied Physics", "Linear Algebra", "Calculus", "AICT");
        courseChoice3.getItems().addAll("Islamiat", "Functional English", "Pak. Stds", " Statistics");

        registerButton.setOnAction(event -> handleRegisterButtonClick());
        backreg.setOnMouseClicked(event -> Main.changeScene("/Front_End/mainscreen.fxml"));

    }
//    @FXML
//    private void handleRegisterButtonAction(ActionEvent event) {
//        // Assuming you have already created a Student object named 'student'
//        String filePath = "/path/to/your/directory/student_info.txt";
//        saveStudentInfoToFile(student, filePath);
//    }

    private void handleRegisterButtonClick() {
        String name = nameText.getText();
        String lastName = lastnameText.getText();
        String selectedCourse1 = courseChoice1.getValue();
        String selectedCourse2 = courseChoice2.getValue();
        String selectedCourse3 = courseChoice3.getValue();

        String randomID = generateRandomID(6);
        nameLabel.setText(name + " " + lastName);
        idLabel.setText(randomID);

        course1.setText(selectedCourse1 != null ? selectedCourse1 : " Not Selected");
        course2.setText(selectedCourse2 != null ? selectedCourse2 : " Not Selected");
        course3.setText(selectedCourse3 != null ? selectedCourse3 : " Not Selected");

        ch1.setText("4");
        ch2.setText("3");
        ch3.setText("2");

        // Create Student object and add it to the list
        Student student = new Student(name + " " + lastName, randomID, selectedCourse1, selectedCourse2, selectedCourse3);
        studentList.add(student);

        // Save student information to a file
//        saveStudentInfoToFile(student);
//        String filePath = "/Data/student_info.txt";
        String filePath = "src/data/student_info.txt";

        saveStudentInfoToFile(student, "src/Data/student_info.txt");
    }

    private String generateRandomID(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append((char) ((int) (Math.random() * 26) + 'A'));
        }
        return sb.toString();
    }

//    private void saveStudentInfoToFile(Student student) {
//        try (FileWriter writer = new FileWriter("student_info.txt", true)) {
//            writer.write(student.toString() + "\n");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//

    private void saveStudentInfoToFile(Student student, String filePath) {
//        try (FileWriter writer = new FileWriter("student_info.txt", true)) {
//            writer.write(student.toString() + "\n");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write(student.toString() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
