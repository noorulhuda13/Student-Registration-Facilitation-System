package Back_End;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    private static Stage primaryStage;
    private static studentviewController studentViewController;

    public static void setStudentViewController(studentviewController controller) {
        studentViewController = controller;
    }

    public static studentviewController getStudentViewController() {
        return studentViewController;
    }

    @Override
    public void start(Stage primaryStage) {
        Main.primaryStage = primaryStage;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Front_End/mainscreen.fxml"));
            Parent root = loader.load();
            primaryStage.setTitle("Main Screen");
            primaryStage.setScene(new Scene(root, 1286, 800));
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void changeScene(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxml));
            Parent pane = loader.load();
            primaryStage.getScene().setRoot(pane);

            if (fxml.equals("/Front_End/studentview.fxml")) {
                studentviewController controller = loader.getController();
                setStudentViewController(controller);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
