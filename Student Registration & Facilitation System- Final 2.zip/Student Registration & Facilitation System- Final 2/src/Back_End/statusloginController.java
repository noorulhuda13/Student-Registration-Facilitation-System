package Back_End;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class statusloginController {

    @FXML
    private AnchorPane StatusLoginAnchorPane;

    @FXML
    private ImageView backbutton;

    @FXML
    private TextField id;

    @FXML
    private TextField pass;

    @FXML
    private ImageView studentbutton;

    @FXML
    private ImageView teacherbutton;

    @FXML
    public void initialize() {
        backbutton.setOnMouseClicked(event -> Main.changeScene("/Front_End/mainscreen.fxml"));

        studentbutton.setOnMouseClicked(event -> {
            if ("Hassan036".equals(id.getText()) && "HassanRamay".equals(pass.getText())) {
                Main.changeScene("/Front_End/studentview.fxml");
            }
        });

        teacherbutton.setOnMouseClicked(event -> {
            if ("Iffat".equals(id.getText()) && "Iffat92".equals(pass.getText())) {
                Main.changeScene("/Front_End/teacherview.fxml");
            }
        });
    }
}
