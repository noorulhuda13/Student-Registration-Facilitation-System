package Back_End;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class MainController {

    @FXML
    private ImageView Registrationbutton;

    @FXML
    private ImageView LectureStatusButton;

    @FXML
    public void initialize() {
        Registrationbutton.setOnMouseClicked(event -> {
            try {
                Main.changeScene("/Front_End/project.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        LectureStatusButton.setOnMouseClicked(event -> {
            try {
                Main.changeScene("/Front_End/statuslogin.fxml");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
