package Back_End;

import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.event.ActionEvent;

public class teacherviewController {

    @FXML
    private ChoiceBox<String> classChoiceBox;

    @FXML
    private ImageView logoutteacherview;

    @FXML
    private RadioButton noButton;

    @FXML
    private RadioButton yesButton;

    private ToggleGroup lectureToggleGroup;

    @FXML
    public void initialize() {
        logoutteacherview.setOnMouseClicked(event -> Main.changeScene("/Front_End/statuslogin.fxml"));

        lectureToggleGroup = new ToggleGroup();
        yesButton.setToggleGroup(lectureToggleGroup);
        noButton.setToggleGroup(lectureToggleGroup);

        lectureToggleGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (lectureToggleGroup.getSelectedToggle() != null) {
                RadioButton selectedRadioButton = (RadioButton) lectureToggleGroup.getSelectedToggle();
                if (selectedRadioButton.equals(yesButton)) {
                    studentviewController.updateLectureStatus("As Scheduled");
                } else if (selectedRadioButton.equals(noButton)) {
                    studentviewController.updateLectureStatus("Cancelled");
                }
            }
        });

        classChoiceBox.getItems().addAll("BCE-A", "BCE-B");
    }
}
