package Back_End;
import java.util.Objects;

public class Student {
    private String fullName;
    private String studentID;
    private String course1;
    private String course2;
    private String course3;

    public Student(String fullName, String studentID, String course1, String course2, String course3) {
        this.fullName = fullName;
        this.studentID = studentID;
        this.course1 = course1;
        this.course2 = course2;
        this.course3 = course3;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getCourse1() {
        return course1;
    }

    public void setCourse1(String course1) {
        this.course1 = course1;
    }

    public String getCourse2() {
        return course2;
    }

    public void setCourse2(String course2) {
        this.course2 = course2;
    }

    public String getCourse3() {
        return course3;
    }

    public void setCourse3(String course3) {
        this.course3 = course3;
    }

    @Override
    public String toString() {
        return fullName + "," + studentID + "," + course1 + "," + course2 + "," + course3;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(fullName, student.fullName) && Objects.equals(studentID, student.studentID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fullName, studentID);
    }
}
