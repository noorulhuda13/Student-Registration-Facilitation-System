package Back_End;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class studentviewController {

    @FXML
    private ImageView studentviewlogout;

    @FXML
    private Label c1label;

    @FXML
    private Label c2label;

    @FXML
    private Label c3label;

    @FXML
    private Label s1label;

    @FXML
    private Label s2label;

    @FXML
    private Label s3label;

    private static String lectureStatus;

    @FXML
    public void initialize() {
        studentviewlogout.setOnMouseClicked(event -> Main.changeScene("/Front_End/statuslogin.fxml"));

        s1label.setText("As Scheduled");
        s2label.setText("As Scheduled");
        s3label.setText(lectureStatus);

        c1label.setText("OOP");
        c2label.setText("Linear Algebra");
        c3label.setText("Islamiat");
    }

    public static void updateLectureStatus(String status) {
        lectureStatus = status;
        if (Main.getStudentViewController() != null) {
            Main.getStudentViewController().s3label.setText(status);
        }
    }
}
